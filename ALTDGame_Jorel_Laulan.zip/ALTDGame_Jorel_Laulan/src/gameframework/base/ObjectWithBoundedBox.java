package gameframework.base;

import java.awt.*;

public interface ObjectWithBoundedBox {
	Rectangle getBoundingBox();
}
