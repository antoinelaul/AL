package gameframework.base;

import java.awt.*;

public interface Drawable {
	public void draw(Graphics g);
}
