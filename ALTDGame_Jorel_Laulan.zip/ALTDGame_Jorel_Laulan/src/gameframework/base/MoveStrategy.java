package gameframework.base;

public interface MoveStrategy {
	SpeedVector getSpeedVector();
}
