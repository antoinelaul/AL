package gameframework.base;

import java.awt.*;

public interface
Overlappable extends ObjectWithBoundedBox {
	public Point getPosition();
}
