package gameframework.game;

public interface GameEntity {
}
