package gameframework.game;

import gameframework.base.ObjectWithBoundedBox;

public interface MoveBlocker extends ObjectWithBoundedBox {
}
