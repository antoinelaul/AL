package gameframework.game;

public interface GameUniverseViewPort {
	public void paint();

	public void refresh();
}
