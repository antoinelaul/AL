package gameframework.game;

public interface GameLevel extends Runnable {
	public void start();
}
